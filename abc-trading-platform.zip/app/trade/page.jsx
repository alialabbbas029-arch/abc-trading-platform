import Header from '../components/Header'
import TradeWidget from '../components/TradeWidget'
export default function TradePage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Header />
      <section className="container mx-auto p-6 flex-1">
        <h1 className="text-2xl font-bold mb-4">لوحة التداول</h1>
        <TradeWidget />
      </section>
    </main>
  )
}
