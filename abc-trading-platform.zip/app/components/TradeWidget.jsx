'use client'
import { useState } from 'react'
export default function TradeWidget(){
  const [pair, setPair] = useState('BTC/USDT')
  const [side, setSide] = useState('BUY')
  const [amount, setAmount] = useState('0.01')
  function placeOrder(){ alert(`Order: ${side} ${amount} ${pair}`) }
  return (
    <div className="bg-white rounded p-4 shadow max-w-lg">
      <div className="flex items-center justify-between mb-4">
        <select value={pair} onChange={e=>setPair(e.target.value)} className="border p-2 rounded">
          <option>BTC/USDT</option><option>ETH/USDT</option><option>XRP/USDT</option>
        </select>
        <div>
          <button onClick={()=>setSide('BUY')} className="px-3 py-1 border rounded mr-2">BUY</button>
          <button onClick={()=>setSide('SELL')} className="px-3 py-1 border rounded">SELL</button>
        </div>
      </div>
      <label className="block mb-2">الكمية</label>
      <input value={amount} onChange={e=>setAmount(e.target.value)} className="w-full p-2 border rounded mb-4" />
      <div className="flex justify-end">
        <button onClick={placeOrder} className="px-4 py-2 rounded bg-blue-600 text-white">تنفيذ</button>
      </div>
    </div>
  )
}
