export async function GET(req) {
  return new Response(JSON.stringify({ message: 'hello from ABC API' }), { status: 200 })
}
