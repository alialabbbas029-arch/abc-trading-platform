# ABC Trading Platform

1. npm install
2. npm run dev
3. npm run build
4. Deploy on Vercel
