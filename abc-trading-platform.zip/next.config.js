const nextConfig = {
  reactStrictMode: true,
  i18n: { locales: ["en", "ar"], defaultLocale: "ar" },
}
module.exports = nextConfig
